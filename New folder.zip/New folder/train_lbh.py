import cv2
import os
import numpy as np

def collect_training_data(dataset_path="dataset"):
    print(f"Looking for images in: {dataset_path}")
    images = []
    labels = []
    label_map = {}  # Maps label_id -> person_name
    current_label_id = 0

    for person_name in os.listdir(dataset_path):
        person_folder = os.path.join(dataset_path, person_name)
        if not os.path.isdir(person_folder):
            continue

        # Assign a numeric label to this person
        label_map[current_label_id] = person_name

        for filename in os.listdir(person_folder):
            if filename.lower().endswith(('.jpg', '.png', '.jpeg')):
                img_path = os.path.join(person_folder, filename)
                img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
                if img is None:
                    continue

                images.append(img)
                labels.append(current_label_id)

        current_label_id += 1

    return images, labels, label_map

def train_lbph_recognizer(images, labels):
    # Create an LBPH face recognizer
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    # Train on the collected images
    recognizer.train(images, np.array(labels))
    return recognizer

if __name__ == "__main__":
    images, labels, label_map = collect_training_data("dataset")
    recognizer = train_lbph_recognizer(images, labels)
    # Save the model
    recognizer.write("lbph_model.xml")

    # Also save the label_map for reference
    # (You can pickle it or just store it in a JSON file)
    import pickle
    with open("label_map.pkl", "wb") as f:
        pickle.dump(label_map, f)

    print("Training complete. Model and label map saved.")
