import cv2
import torch
import pickle
import numpy as np

########################
# 1. Load YOLO model
########################
# This downloads or loads the yolov5n weights by default.
model = torch.hub.load('ultralytics/yolov5', 'yolov5n')  # 'yolov5n' = Nano model

########################
# 2. Load LBPH model & label map
########################
recognizer = cv2.face.LBPHFaceRecognizer_create()
recognizer.read("lbph_model.xml")  # path to your trained LBPH model

with open("label_map.pkl", "rb") as f:
    label_map = pickle.load(f)
# label_map is something like {0: "Alice", 1: "Bob", ...}

########################
# 3. Initialize Haar Cascade
########################
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")

########################
# 4. Initialize Webcam
########################
cap = cv2.VideoCapture(0)  # or cap = cv2.VideoCapture(0, cv2.CAP_DSHOW) on Windows if MSMF issues

while True:
    ret, frame = cap.read()
    if not ret:
        break

    # --- YOLO Inference ---
    results = model(frame)
    # results.xyxy[0] is a Nx6 tensor [x1, y1, x2, y2, conf, class]

    detections = results.xyxy[0].cpu().numpy()
    for *box, conf, cls in detections:
        # 5. Check if detection is "person" (class 0 in COCO)
        if int(cls) == 0:  # 'person'
            x1, y1, x2, y2 = map(int, box)

            # --- Crop Person ROI ---
            person_roi = frame[y1:y2, x1:x2]

            # --- Convert ROI to Grayscale for face detection & LBPH ---
            gray_roi = cv2.cvtColor(person_roi, cv2.COLOR_BGR2GRAY)

            # --- Haar Cascade Face Detection in the person ROI ---
            faces = face_cascade.detectMultiScale(
                gray_roi,
                scaleFactor=1.1,
                minNeighbors=5,
                minSize=(30, 30)
            )

            for (fx, fy, fw, fh) in faces:
                face_crop = gray_roi[fy:fy+fh, fx:fx+fw]

                # --- Predict with LBPH ---
                label_id, confidence = recognizer.predict(face_crop)

                # Lower confidence => better match. Adjust threshold to your needs
                if confidence < 95:
                    name = label_map[label_id]
                    text = f"{name} ({confidence:.0f})"
                else:
                    text = f"Unrecognized ({confidence:.0f})"

                # --- Draw face box & label on the person ROI ---
                cv2.rectangle(person_roi, (fx, fy), (fx+fw, fy+fh), (0, 255, 0), 2)
                cv2.putText(person_roi, text, (fx, fy - 10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)

            # --- Draw Person Bounding Box on the Main Frame ---
            cv2.rectangle(frame, (x1, y1), (x2, y2), (255, 0, 0), 2)
            cv2.putText(frame, f"Person {conf:.2f}",
                        (x1, y1 - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 1)

    # --- Display ---
    cv2.imshow("YOLO + LBPH Recognition", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
