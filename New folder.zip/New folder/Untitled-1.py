import torch
import cv2

# 1. Load the YOLOv5 model
model = torch.hub.load('ultralytics/yolov5', 'yolov5n')  # or 'yolov5s', etc.

# 2. Initialize the webcam
cap = cv2.VideoCapture(0)  # 0 = default webcam
if not cap.isOpened():
    print("Could not open webcam")
    exit()

while True:
    ret, frame = cap.read()
    if not ret:
        break

    # 3. Run YOLOv5 inference
    results = model(frame)

    # 4. Annotate frame with bounding boxes
    #    'results.render()' returns a list of images (with annotations) in-place
    annotated_frame = results.render()[0]

    # 5. Show the video stream
    cv2.imshow('Webcam', annotated_frame)

    # Press 'q' to quit
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
