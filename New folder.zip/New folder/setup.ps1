# setup.ps1
# This PowerShell script creates a virtual environment (if one doesn’t exist),
# activates it, upgrades pip, and installs all required packages from requirements.txt.

# Ensure you're in the project root folder, e.g., "C:\Users\ernie\Desktop\Group proj"

# 1. Create a virtual environment if it doesn't exist.
if (!(Test-Path -Path "./venv")) {
    Write-Host "Creating virtual environment..."
    python -m venv venv
} else {
    Write-Host "Virtual environment already exists."
}

# 2. Activate the virtual environment.
Write-Host "Activating virtual environment..."
. .\venv\Scripts\Activate.ps1

# 3. Upgrade pip.
Write-Host "Upgrading pip..."
pip install --upgrade pip

# 4. Install dependencies.
Write-Host "Installing dependencies from requirements.txt..."
pip install -r requirements.txt

Write-Host "Setup complete! Your virtual environment is ready."
