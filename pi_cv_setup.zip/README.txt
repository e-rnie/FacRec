Pi CV Setup Bundle
==================

This archive contains:
  * `commands/*.txt` – plain‑text files you can open on the Pi and **copy‑paste each block**.
    Each file begins with prerequisites so you know when to run it.
  * `scripts/*.py` – ready‑to‑run Python examples (`detect.py`, `face_id.py`, `combo.py`).
  * `service/cv.service` – a sample systemd unit that auto‑starts `combo.py` on boot.

How to use
----------

1.  Copy the entire folder (or unzip it directly) onto your Pi, e.g. into `/home/pi/cv`.
2.  Work through the `commands` files **in numeric order**.
3.  Place a few JPGs of each known person inside `faces/` (create it next to the scripts)
    *before* running `face_id.py` or `combo.py`.
4.  To enable auto‑start, copy `service/cv.service` to `/etc/systemd/system/`
    and follow the instructions in `commands/07-make_service.txt`.

Everything assumes a 32‑bit Raspberry Pi OS Bookworm image on a Raspberry Pi 4.
