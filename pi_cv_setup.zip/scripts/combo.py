#!/usr/bin/env python3
"""Detect person bboxes with YOLOv8 then run face recognition inside them."""
from ultralytics import YOLO
import face_recognition, cv2, pickle, os

if not os.path.exists("known_encodings.pkl"):
    raise SystemExit("Run face_id.py once to create known_encodings.pkl")

encodings, names = pickle.load(open("known_encodings.pkl", "rb"))
yolo = YOLO('yolov8n.pt')

cap = cv2.VideoCapture(0, cv2.CAP_V4L2)

while True:
    ok, frame = cap.read()
    if not ok:
        break

    results = yolo(frame, classes=[0], verbose=False)[0]  # class 0 = person

    for box in results.boxes:
        x1,y1,x2,y2 = map(int, box.xyxy[0])
        crop = frame[y1:y2, x1:x2]
        rgb = cv2.cvtColor(crop, cv2.COLOR_BGR2RGB)
        flocs = face_recognition.face_locations(rgb, model="hog")
        fencs = face_recognition.face_encodings(rgb, flocs)

        for (top,right,bottom,left), enc in zip(flocs, fencs):
            match = face_recognition.compare_faces(encodings, enc, 0.55)
            label = names[match.index(True)] if True in match else "Unknown"
            cv2.rectangle(frame,
                          (x1+left, y1+top),
                          (x1+right, y1+bottom),
                          (0,255,255), 2)
            cv2.putText(frame, label,
                        (x1+left, y1+top-10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,255,255), 2)

    cv2.imshow("Combined", frame)
    if cv2.waitKey(1) == 27:
        break

cap.release()
cv2.destroyAllWindows()
