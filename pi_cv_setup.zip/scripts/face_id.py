#!/usr/bin/env python3
"""Live face recognition from Pi camera using face_recognition + OpenCV.

Place reference JPGs/PNGs for each person inside a folder named 'faces'
next to this script **before first run**. Filenames become the labels.
"""
import face_recognition, cv2, os, pickle, sys

DATA = "known_encodings.pkl"

def build_database(folder="faces"):
    encodings, names = [], []
    for img in os.listdir(folder):
        path = os.path.join(folder, img)
        frame = face_recognition.load_image_file(path)
        boxes = face_recognition.face_locations(frame, model="hog")
        enc = face_recognition.face_encodings(frame, boxes)
        if enc:
            encodings.append(enc[0])
            names.append(os.path.splitext(img)[0])
    with open(DATA, "wb") as f:
        pickle.dump((encodings, names), f)

if not os.path.exists(DATA):
    print("[*] Building face database…")
    build_database()

known_enc, known_names = pickle.load(open(DATA, "rb"))
cap = cv2.VideoCapture(0, cv2.CAP_V4L2)

while True:
    ok, frame = cap.read()
    if not ok:
        break
    small = cv2.resize(frame, (0,0), fx=0.25, fy=0.25)
    rgb = cv2.cvtColor(small, cv2.COLOR_BGR2RGB)

    boxes = face_recognition.face_locations(rgb, model="hog")
    encs = face_recognition.face_encodings(rgb, boxes)

    for (top,right,bottom,left), enc in zip(boxes, encs):
        matches = face_recognition.compare_faces(known_enc, enc, 0.55)
        name = "Unknown"
        if True in matches:
            name = known_names[matches.index(True)]
        top,right,bottom,left = [v*4 for v in (top,right,bottom,left)]
        cv2.rectangle(frame, (left,top), (right,bottom), (255,0,0), 2)
        cv2.putText(frame, name, (left, top-10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,0,0), 2)

    cv2.imshow("Faces", frame)
    if cv2.waitKey(1) == 27:
        break

cap.release()
cv2.destroyAllWindows()
