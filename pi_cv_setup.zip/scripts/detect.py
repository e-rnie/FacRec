#!/usr/bin/env python3
"""Object detection with YOLOv8 nano model on Raspberry Pi camera."""
from ultralytics import YOLO
import cv2, sys

cap = cv2.VideoCapture(0, cv2.CAP_V4L2)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)

model = YOLO('yolov8n.pt')

while True:
    ok, frame = cap.read()
    if not ok:
        break
    results = model(frame, verbose=False)[0]
    for box in results.boxes:
        x1,y1,x2,y2 = map(int, box.xyxy[0])
        cls = model.names[int(box.cls[0])]
        cv2.rectangle(frame, (x1,y1), (x2,y2), (0,255,0), 2)
        cv2.putText(frame, cls, (x1, y1-10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,255,0), 2)
    cv2.imshow("YOLOv8", frame)
    if cv2.waitKey(1) == 27:  # ESC
        break

cap.release()
cv2.destroyAllWindows()
