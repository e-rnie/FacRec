Face‑Recognition (LBPH) Quick Pack
==================================

This bundle contains:

  * `commands.txt` – ready‑to‑paste install & run blocks.
  * `train_lbph.py` – trainer that builds an LBPH model from images
    in `face_data/<person>/`.
  * `recognise_lbph.py` – live camera recogniser (ESC to quit).

Designed for stock Raspbian Buster/Bullseye (Python 3.7, OpenCV 3.2).
No compiling, no external wheels – everything comes from APT.
