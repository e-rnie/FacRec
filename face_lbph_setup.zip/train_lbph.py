#!/usr/bin/env python3
import cv2, os, numpy as np, pathlib, pickle

DATA_DIR = pathlib.Path("face_data")
MODEL, LABELS = "lbph.yml", "labels.pkl"

detector = cv2.CascadeClassifier(cv2.data.haarcascades +
                                 "haarcascade_frontalface_default.xml")
faces, ids, names = [], [], []

for idx, person in enumerate(sorted(DATA_DIR.iterdir())):
    if not person.is_dir(): continue
    names.append(person.name)
    for img_file in person.glob("*"):
        img = cv2.imread(str(img_file), cv2.IMREAD_GRAYSCALE)
        if img is None: continue
        rects = detector.detectMultiScale(img, 1.3, 5)
        for (x,y,w,h) in rects:
            faces.append(img[y:y+h, x:x+w])
            ids.append(idx)

if not faces:
    raise SystemExit("No faces found – add images to face_data/<name>/")

rec = cv2.face.LBPHFaceRecognizer_create()
rec.train(faces, np.array(ids))
rec.save(MODEL)
pickle.dump(names, open(LABELS, "wb"))
print(f"[+] Saved model {MODEL} with {len(faces)} samples.")
