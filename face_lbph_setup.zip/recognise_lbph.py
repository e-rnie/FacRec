#!/usr/bin/env python3
import cv2, pickle, time

rec = cv2.face.LBPHFaceRecognizer_create()
rec.read("lbph.yml")
names = pickle.load(open("labels.pkl", "rb"))

detector = cv2.CascadeClassifier(cv2.data.haarcascades +
                                 "haarcascade_frontalface_default.xml")

cap = cv2.VideoCapture(0, cv2.CAP_V4L2)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
print("[*] ESC to quit")

while True:
    ok, frame = cap.read()
    if not ok:
        time.sleep(0.05); continue
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    rects = detector.detectMultiScale(gray, 1.3, 5)
    for (x,y,w,h) in rects:
        label, conf = rec.predict(gray[y:y+h, x:x+w])
        name = names[label] if conf < 70 else "Unknown"
        cv2.rectangle(frame, (x,y), (x+w, y+h), (0,255,0), 2)
        cv2.putText(frame, f"{name} {conf:.0f}", (x, y-10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,255,0), 2)
    cv2.imshow("LBPH Face‑ID", frame)
    if cv2.waitKey(1) == 27: break

cap.release()
cv2.destroyAllWindows()
